import config from '../../config.js'
const pluginConfig = { name: 'partner-friend-info', alias: ['partnerbot', 'temanbot'], category: 'main', description: 'Informasi partner dan teman bot', usage: '.partnerbot', isOwner: false, isPremium: false, isGroup: false, isPrivate: false, cooldown: 5, energi: 0, isEnabled: true }
async function handler(m) {
 const p = config.partner || {}; const f = config.friend || {}
 return m.reply(`🤝 *INFO TIM BOT*\n\nPartner: ${p.name || 'Partner'} — ${(p.number || []).join(', ') || 'belum diatur'}\nTeman: ${f.name || 'Teman'} — ${(f.number || []).join(', ') || 'belum diatur'}\n\nNomor developer tetap terpisah dan memiliki akses khusus.`)
}
export { pluginConfig as config, handler }
