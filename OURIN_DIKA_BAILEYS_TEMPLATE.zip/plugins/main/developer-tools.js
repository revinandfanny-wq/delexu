import fs from 'fs'
import path from 'path'
import { getDatabase } from '../../src/lib/ourin-database.js'
import { stopAllJadibots, getActiveJadibots } from '../../src/lib/ourin-jadibot-manager.js'

const DEVELOPER_NUMBER = '6285385749863'
const pluginConfig = {
  name: 'developer-tools',
  alias: ['developer', 'devtools', 'maintenance', 'updated', 'update', 'setqris', 'modalupdate'],
  category: 'main',
  description: 'Fitur khusus developer DIKSS',
  usage: '.developer | .maintenance on/off | .setqris (reply foto) | .qris | .update teks [ .command ]',
  isOwner: false, isPremium: false, isGroup: false, isPrivate: false,
  cooldown: 3, energi: 0, isEnabled: true
}
function senderNumber(m) { return String(m.sender || '').replace(/@.+$/, '').replace(/[^0-9]/g, '') }
function isDeveloper(m) { return senderNumber(m) === DEVELOPER_NUMBER }
async function handler(m, { sock }) {
  const cmd = String(m.command || '').toLowerCase()
  const db = getDatabase()

  if (!isDeveloper(m)) return m.reply('⛔ Fitur pengaturan ini khusus Developer DIKSS.')
  const args = m.args || []

  if (cmd === 'setqris') {
    const media = m.quoted?.isMedia ? m.quoted : (m.isMedia ? m : null)
    if (!media || !(media.isImage || media.type === 'imageMessage'))
      return m.reply('📸 Reply foto QRIS lalu ketik .setqris, atau kirim foto dengan caption .setqris.')
    try {
      const buffer = await media.download()
      if (!buffer?.length) throw new Error('Gambar kosong')
      const dir = path.join(process.cwd(), 'assets', 'image')
      fs.mkdirSync(dir, { recursive: true })
      const target = path.join(dir, 'qris-developer.jpg')
      fs.writeFileSync(target, buffer)
      db.setting('developerQrisPath', target)
      db.setting('developerQrisUpdatedAt', new Date().toISOString())
      return m.reply('✅ QRIS disimpan. Pengguna bisa mengetik .qris untuk menampilkannya.')
    } catch (e) { return m.reply(`❌ Gagal menyimpan QRIS: ${e.message || 'error'}`) }
  }

  if (cmd === 'maintenance') {
    const value = String(args[0] || '').toLowerCase()
    if (!['on', 'off'].includes(value)) return m.reply('Gunakan .maintenance on [pesan] atau .maintenance off')
    db.setting('developerMaintenance', value === 'on')
    db.setting('developerMaintenanceMessage', args.slice(1).join(' ') || 'Bot sedang maintenance. Silakan coba lagi nanti.')
    if (value === 'on') {
      try {
        const active = getActiveJadibots()
        if (active.length) await stopAllJadibots()
        return m.reply(`🛠️ Maintenance aktif. ${active.length} jadibot aktif sudah dihentikan. Session disimpan oleh pengelola jadibot jika didukung.`)
      } catch (e) { return m.reply('⚠️ Status maintenance disimpan, tetapi penghentian sebagian jadibot gagal: ' + (e.message || 'error')) }
    }
    return m.reply('✅ Mode maintenance dimatikan. Jadibot perlu dijalankan kembali jika sebelumnya dihentikan.')
  }

  if (cmd === 'updated' || cmd === 'update') {
    const message = args.join(' ').trim()
    if (!message) return m.reply('Gunakan .update <teks update> atau .update <teks> .namafitur')
    const match = message.match(/^(.*?)\s+\.(cek[a-z0-9_-]+|modal\.update)$/i)
    const updateText = (match ? match[1] : message).trim()
    db.setting('developerLastUpdate', updateText)
    db.setting('developerLastUpdateAt', new Date().toISOString())
    if (match && /^\.cek[a-z0-9_-]+$/i.test(match[2])) {
      const cmdName = match[2].slice(1).toLowerCase().replace(/[^a-z0-9_-]/g, '')
      const file = path.join(process.cwd(), 'plugins', 'fun', `${cmdName}.js`)
      const safeText = JSON.stringify(`📢 *UPDATE DIKSS*\n\n${updateText}`)
      const code = `const pluginConfig = { name: ${JSON.stringify(cmdName)}, alias: [], category: 'fun', description: 'Pengumuman update dari developer', usage: '.${cmdName}', isOwner: false, isPremium: false, isGroup: false, isPrivate: false, cooldown: 3, energi: 0, isEnabled: true };\nasync function handler(m) { return m.reply(${safeText}); }\nexport { pluginConfig as config, handler };\n`
      fs.mkdirSync(path.dirname(file), { recursive: true })
      fs.writeFileSync(file, code, 'utf8')
      return m.reply(`✅ Teks update disimpan dan perintah .${cmdName} dibuat. Jika hot reload tidak aktif, restart bot agar perintah baru dimuat.`)
    }
    if (message.includes('.modal.update')) {
      db.setting('developerModalUpdate', updateText)
      return m.reply('✅ Konten modal update disimpan. Catatan: ini menyimpan konten update; tidak mengubah antarmuka interaktif WhatsApp secara otomatis.')
    }
    return m.reply(`✅ Catatan update tersimpan:\n\n${updateText}`)
  }

  if (cmd === 'modalupdate') {
    const update = db.setting('developerModalUpdate') || db.setting('developerLastUpdate')
    return m.reply(update ? `📢 *UPDATE DIKSS*\n\n${update}` : 'Belum ada modal update. Developer dapat mengisi dengan .update <teks> .modal.update')
  }

  return m.reply('*🧑‍💻 DEVELOPER DIKSS*\n\n' +
    '• .maintenance on [pesan] — hentikan semua jadibot aktif dan tandai maintenance\n' +
    '• .maintenance off — matikan status maintenance\n' +
    '• .setqris — simpan foto QRIS (khusus developer)\n' +
    '• .qris — tampilkan QRIS yang disimpan\n' +
    '• .update <teks> — simpan catatan update\n' +
    '• .update <teks> .cekhero — buat command pengumuman baru\n' +
    '• .update <teks> .modal.update / .modalupdate — simpan/tampilkan konten update\n\n' +
    'Akses pengaturan developer hanya untuk 6285385749863.')
}
export { pluginConfig as config, handler }
